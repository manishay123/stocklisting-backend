//package com.stackroute.StockService.service;
//
//import com.stackroute.StockService.Service.StockService;
//import com.stackroute.StockService.Service.StockServiceImpl;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//@ExtendWith(MockitoExtension.class)
//public class StockServiceTest {
//
//    @InjectMocks
//    StockServiceImpl stockService;
//
//    @Test
//    public void getStocksByCountryName(){
//        stockService.getStocksByCountryName("India");
//
//    }
//}
