package com.stackroute.StockService.Repository;

public class StockRepository {

}
